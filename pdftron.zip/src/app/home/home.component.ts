import { Component, ViewChild, OnInit, ElementRef, AfterViewInit } from '@angular/core';
import WebViewer from '@pdftron/webviewer';
import { GlobalService } from '../services/global.service';
import { Router, ActivatedRoute, NavigationEnd, ParamMap } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
declare var $: any;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit, AfterViewInit {
  @ViewChild('viewer',{static: false}) viewer: ElementRef;
  wvInstance: any;
  ngOnInit(){
    
  }
  ngAfterViewInit(): void {​​​​​​​
  
  WebViewer({​​​​​​​
    path: '../lib',
    initialDoc: '../files/webviewer-demo-annotated.pdf'
  }​​​​​​​, this.viewer.nativeElement).then(instance => {​​​​​​​
    this.wvInstance = instance;
    const {​​​​​​​ Annotations, annotManager, docViewer }​​​​​​​ = this.wvInstance;
    // now you can access APIs through this.webviewer.getInstance()
    instance.openElements(['notesPanel']);
    // see https://www.pdftron.com/documentation/web/guides/ui/apis for the full list of APIs
  
  
    // or listen to events from the viewer element
    this.viewer.nativeElement.addEventListener('pageChanged', (e) => {​​​​​​​
      const [ pageNumber ] = e.detail;
      console.log(`Current page is ${​​​​​​​pageNumber}​​​​​​​`);
    }​​​​​​​);
  
  
    // or from the docViewer instance
    instance.docViewer.on('annotationsLoaded', () => {​​​​​​​
      console.log('annotations loaded');
    }​​​​​​​);
  
  
    // instance.docViewer.on('documentLoaded', this.wvDocumentLoadedHandler)
   instance.docViewer.on('documentLoaded', async () => {​​​​​​​
      const freeText = new Annotations.FreeTextAnnotation();
      const pageNo = 1;
      freeText.PageNumber = pageNo;
      freeText.X = 370;
      freeText.Y = 5;
      freeText.Width = 235;
      freeText.Height = 50;
      freeText.setPadding(new Annotations.Rect(0, 0, 0, 0));
      freeText.setContents('Welcome');
      freeText.FillColor = new Annotations.Color(255,255,255);
      freeText.TextColor = new Annotations.Color("#000000");
      freeText.FontSize = "16pt";
      annotManager.addAnnotation(freeText, {​​​​​​​ autoFocus: false }​​​​​​​);
      annotManager.redrawAnnotation(freeText);
  
      // Save PDF:
      const doc = docViewer.getDocument();
      const xfdfString = await annotManager.exportAnnotations();
      const options = {​​​​​​​ xfdfString }​​​​​​​;
      const data = await doc.getFileData(options);
      const arr = new Uint8Array(data);
      const blob = new Blob([arr], {​​​​​​​ type: "application/pdf" }​​​​​​​);
      console.log({​​​​​​​ blob }​​​​​​​)
    }​​​​​​​)
  }​​​​​​​)

  }​​​​​​​
  
  }​​​​​​​