import { Component, ViewChild, OnInit, ElementRef, AfterViewInit } from '@angular/core';
import WebViewer from '@pdftron/webviewer';
import { GlobalService } from './services/global.service';
import {Title} from "@angular/platform-browser";
declare var $: any;
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  
  
  constructor(public global: GlobalService,private titleService:Title){
    this.titleService.setTitle("Indexing Application");
  }
  ngOnInit() {
    // var docId = 1;
    // this.getDocDetailsByID(docId)
    // this.wvDocumentLoadedHandler = this.wvDocumentLoadedHandler.bind(this);
  }
}
